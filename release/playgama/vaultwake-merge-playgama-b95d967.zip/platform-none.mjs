// Playgama build: the Classic platform module (v4/platform.mjs, a CrazyGames wrapper) is not shipped.
export const platform={init:async()=>false,startGameplay:async()=>{},event(){},save:async s=>s,audioMuted:()=>false,onAudioSettingChange:()=>()=>{}};
