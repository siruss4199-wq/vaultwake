// Playgama build: the platform is always the Playgama Bridge (no CrazyGames adapter is shipped).
export * from './platform-pg.mjs';
